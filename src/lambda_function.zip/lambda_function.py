import logging
import json
logger = logging.getLogger()

def lambda_handler(event, context):

    detail = event.get("detail", {})
    new_eval = detail.get("newEvaluationResult", {})

    compliance_type = new_eval.get("complianceType")
    config_rule_name = detail.get("configRuleName")
    resource_id = detail.get("resourceId")

    if compliance_type.lower() == "non_compliant":
        logger.warning(
                f"WARNING: Bucket access is public! Context: {context}, Event: {event}",
                extra={
                    "context" : context,
                    "event" : event
                },
        )
    else:
        logger.info(
            f"Resource {resource_id} is compliant with rule {config_rule_name}. Context: {context}, Event: {event}",
            extra={
                "context" : context,
                "event" : event
            }
        )

    return {
        'statusCode': 200,
        'body': json.dumps('Compliance status processed successfully')
    }
    